import si.fri.algator.execute.AbstractTestCase;

/**
 * 
 * @author tomaz
 */
public class TestCase extends AbstractTestCase {

  @Override
  public Input getInput() {
    return (Input) super.getInput(); 
  } 

  @Override
  public Output getExpectedOutput() {
    return (Output) super.getExpectedOutput();
  }
}