/**
  * A class for common static methods (tools) of the project
 * @author tomaz
 */
public class Tools  {

/*
 * In this project, we do not use this class for helper methods. Instead, 
 * we define static methods used in the project in the proj/lib/basicsort/Tools.java 
 * file, which is packaged into a JAR and imported into the project via the 
 * 'ProjectJARs' property.
*/
}